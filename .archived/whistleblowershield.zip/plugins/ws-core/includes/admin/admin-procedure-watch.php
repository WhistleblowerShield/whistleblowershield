<?php
/**
 * admin-procedure-watch.php — Procedure authority link validation + publish gate.
 *
 * Guards against inaccurate authority cross-references on ag-procedure posts.
 * Owns three concerns: mismatch detection, publish gate, admin notice display.
 * Cache invalidation is handled by query-agencies.php (data layer owns cache).
 *
 * DETECTION LOGIC
 * ---------------
 * Hard mismatch: linked jx-statute or jx-common-law has zero ws_protected_disclosure term intersection
 * with this procedure's ws_ag_procedure_protected_disclosures.
 *   → sets ws_ag_procedure_parent_flagged = 1
 *   → demotes published post to draft
 *   → publish gate blocks all subsequent publish attempts
 *
 * Broad-scope advisory (soft — no demotion): procedure has no protected disclosures
 * set AND has statute/common-law links. Links cannot be automatically verified.
 *   → sets ws_ag_procedure_parent_broad_scope = 1
 *   → admin notice only
 *
 * Linked records with no ws_protected_disclosure terms assigned are skipped — the data
 * problem is on the linked-record side, not the procedure side.
 *
 * ADMIN OVERRIDE FLOW
 * -------------------
 * Admin checks field_ag_procedure_parent_override (Admin Review tab) and saves:
 *   wp_insert_post_data fires first — reads $_POST['acf'] directly (before ACF
 *   saves at priority 10) — allows publish through if admin + override set.
 *   acf/save_post (priority 20) fires after — writes override audit log to
 *   ws_ag_procedure_parent_override_log, clears mismatch flag, resets override to 0.
 *
 * @package WhistleblowerShield
 * @since   3.9.0
 * @version    3.20.1
 *
 * VERSION
 * -------
 * 3.9.0   Initial release. Phase 3 of ag-procedure feature build.
 * 3.20.1  Loud-failure pass. Three wp_get_object_terms() calls previously
 *         treated a genuine WP_Error identically to a legitimate empty
 *         result — now logged separately. Most importantly: wp_update_post()
 *         demoting a flagged procedure to draft had its return value
 *         unchecked entirely — if that call failed, the post remained
 *         published with a detected authority-link mismatch while the
 *         admin notice claimed it had been demoted. Now checked and logged.
 */

defined( 'ABSPATH' ) || exit;


// ════════════════════════════════════════════════════════════════════════════
// Detection + Demotion
//
// Runs after ACF writes all fields (priority 10). Reads the new parent IDs
// and protected disclosures from post meta and checks for hard mismatches.
// ════════════════════════════════════════════════════════════════════════════

add_action( 'acf/save_post', 'ws_ag_procedure_check_parent_links', 20 );

/**
 * Validates statute/common-law links on ag-procedure save. Demotes to draft on mismatch.
 *
 * @param  int|string  $post_id  Post ID from acf/save_post.
 */
function ws_ag_procedure_check_parent_links( $post_id ) {

    $post_id = (int) $post_id;

    if ( get_post_type( $post_id ) !== 'ag-procedure' ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
        return;
    }

    // ── Admin override: honour, log, reset, skip check ────────────────────
    //
    // ACF saved ws_ag_procedure_parent_override at priority 10. If it is 1 the admin
    // has explicitly acknowledged the mismatch. Clear the flag, write the
    // audit log, reset the override to 0, then return without checking.

    $override = (bool) get_post_meta( $post_id, 'ws_ag_procedure_parent_override', true );

    if ( $override && current_user_can( 'manage_options' ) ) {

        // Append to audit log before clearing the flag detail.
        $existing_detail = get_post_meta( $post_id, 'ws_ag_procedure_parent_flag_detail', true );
        $log_entry = [
            'user_id'                  => get_current_user_id(),
            'user_name'                => wp_get_current_user()->display_name,
            'timestamp'                => current_time( 'Y-m-d H:i:s' ),
            'mismatches_at_override'   => $existing_detail ? json_decode( $existing_detail, true ) : [],
        ];
        $existing_log = get_post_meta( $post_id, 'ws_ag_procedure_parent_override_log', true );
        $log          = $existing_log ? json_decode( $existing_log, true ) : [];
        if ( ! is_array( $log ) ) $log = [];
        $log[] = $log_entry;
        update_post_meta( $post_id, 'ws_ag_procedure_parent_override_log', wp_json_encode( $log ) );

        // Clear flag and reset override.
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_flagged' );
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_flag_detail' );
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_broad_scope' );
        update_post_meta( $post_id, 'ws_ag_procedure_parent_override', 0 );

        return;
    }

    // ── Read linked authority IDs and procedure protected disclosures ───────────
    // Direct meta and taxonomy reads — acf/save_post context; validation logic that
    // runs during a save cannot route through the query layer's frontend read functions.

    $statute_ids_raw = get_post_meta( $post_id, 'ws_ag_procedure_statute_ids', true );
    $statute_ids     = is_array( $statute_ids_raw ) ? array_map( 'intval', array_filter( $statute_ids_raw ) ) : [];
    $comlaw_ids_raw = get_post_meta( $post_id, 'ws_ag_procedure_comlaw_ids', true );
    $comlaw_ids     = is_array( $comlaw_ids_raw ) ? array_map( 'intval', array_filter( $comlaw_ids_raw ) ) : [];

    // No linked authorities — clear all flags and return clean.
    if ( empty( $statute_ids ) && empty( $comlaw_ids ) ) {
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_flagged' );
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_flag_detail' );
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_broad_scope' );
        return;
    }

    $procedure_disc_types = wp_get_object_terms( $post_id, 'ws_protected_disclosure', [ 'fields' => 'ids' ] );
    if ( is_wp_error( $procedure_disc_types ) ) {
        // Previously silently treated as "no protected disclosures set,"
        // identical to the legitimate case. A genuine query failure here
        // pushes every procedure it touches into the broad-scope advisory
        // path (or worse, masks a real mismatch check below), for a reason
        // that has nothing to do with the procedure's actual data.
        ws_log_loud_failure( new WS_Loud_Failure( 'procedure-watch', "wp_get_object_terms() failed reading ws_protected_disclosure for procedure {$post_id} — treating as empty, which may misclassify this save as broad-scope.", [
            'post_id' => $post_id,
            'error'   => $procedure_disc_types->get_error_message(),
        ] ) );
        $procedure_disc_types = [];
    }

    // ── Broad-scope advisory: no protected disclosures + linked authorities ─────
    //
    // The auto-scoping hook in acf-ag-procedures.php had no taxonomy scope
    // to filter by — the picker showed everything. Any authority links made
    // under these conditions cannot be automatically verified.

    if ( empty( $procedure_disc_types ) ) {
        update_post_meta( $post_id, 'ws_ag_procedure_parent_broad_scope', 1 );
    } else {
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_broad_scope' );
    }

    // ── Hard mismatch check: disclosure-type intersection per linked record ─
    //
    // Skip linked records with no ws_protected_disclosure terms — the incomplete data
    // is a linked-record-side concern. Flagging the procedure for a record's
    // missing taxonomy data misdirects the editor.

    $mismatches = [];

    foreach ( $statute_ids as $statute_id ) {

        if ( ! $statute_id ) continue;

        $statute_disc_types = wp_get_object_terms( $statute_id, 'ws_protected_disclosure', [ 'fields' => 'ids' ] );

        if ( is_wp_error( $statute_disc_types ) ) {
            // Distinct from "linked record legitimately has no terms" —
            // a genuine query failure was previously skipped identically,
            // silently disabling the mismatch check for this statute link
            // on a save where the underlying data may be fine.
            ws_log_loud_failure( new WS_Loud_Failure( 'procedure-watch', "wp_get_object_terms() failed reading ws_protected_disclosure for linked statute {$statute_id} — mismatch check skipped for this link on procedure {$post_id}.", [
                'post_id'    => $post_id,
                'statute_id' => $statute_id,
                'error'      => $statute_disc_types->get_error_message(),
            ] ) );
            continue;
        }

        if ( empty( $statute_disc_types ) ) {
            continue; // Skip: linked record has no protected disclosures — data incomplete on linked-record side.
        }

        if ( ! empty( $procedure_disc_types ) ) {
            $intersection = array_intersect(
                array_map( 'intval', $procedure_disc_types ),
                array_map( 'intval', $statute_disc_types )
            );
            if ( empty( $intersection ) ) {
                $mismatches[] = [
                    'parent_type'   => 'statute',
                    'parent_id'     => $statute_id,
                    'parent_title'  => get_the_title( $statute_id ),
                    'reason'        => 'protected_disclosure_mismatch',
                ];
            }
        }
    }

    foreach ( $comlaw_ids as $comlaw_id ) {

        if ( ! $comlaw_id ) continue;

        $comlaw_disc_types = wp_get_object_terms( $comlaw_id, 'ws_protected_disclosure', [ 'fields' => 'ids' ] );

        if ( is_wp_error( $comlaw_disc_types ) ) {
            ws_log_loud_failure( new WS_Loud_Failure( 'procedure-watch', "wp_get_object_terms() failed reading ws_protected_disclosure for linked common-law record {$comlaw_id} — mismatch check skipped for this link on procedure {$post_id}.", [
                'post_id'   => $post_id,
                'comlaw_id' => $comlaw_id,
                'error'     => $comlaw_disc_types->get_error_message(),
            ] ) );
            continue;
        }

        if ( empty( $comlaw_disc_types ) ) {
            continue; // Skip: linked record has no protected disclosures — data incomplete on linked-record side.
        }

        if ( ! empty( $procedure_disc_types ) ) {
            $intersection = array_intersect(
                array_map( 'intval', $procedure_disc_types ),
                array_map( 'intval', $comlaw_disc_types )
            );
            if ( empty( $intersection ) ) {
                $mismatches[] = [
                    'parent_type'  => 'common_law',
                    'parent_id'    => $comlaw_id,
                    'parent_title' => get_the_title( $comlaw_id ),
                    'reason'       => 'protected_disclosure_mismatch',
                ];
            }
        }
    }

    // ── Act on results ─────────────────────────────────────────────────────

    if ( ! empty( $mismatches ) ) {

        update_post_meta( $post_id, 'ws_ag_procedure_parent_flagged',     1 );
        update_post_meta( $post_id, 'ws_ag_procedure_parent_flag_detail', wp_json_encode( $mismatches ) );

        // Demote to draft if currently published.
        // Static flag prevents wp_update_post() from re-triggering this hook.
        if ( 'publish' === get_post_status( $post_id ) ) {
            static $demoting = false;
            if ( ! $demoting ) {
                $demoting = true;
                $demote_result = wp_update_post( [ 'ID' => $post_id, 'post_status' => 'draft' ], true );
                $demoting = false;
                if ( is_wp_error( $demote_result ) ) {
                    // This is the serious one: the mismatch flag is now set
                    // and the admin notice below will say "This Procedure Is
                    // Saved as a Draft" — but if this call failed, the post
                    // is still live, published, right now, with data the
                    // system just determined is mismatched. Previously
                    // unchecked entirely.
                    ws_log_loud_failure( new WS_Loud_Failure( 'procedure-watch', "Failed to demote flagged procedure {$post_id} to draft — it remains PUBLISHED with a detected authority-link mismatch.", [
                        'post_id' => $post_id,
                        'error'   => $demote_result->get_error_message(),
                    ] ) );
                }
            }
        }

    } else {

        // Clean save — clear any existing hard-mismatch flag.
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_flagged' );
        delete_post_meta( $post_id, 'ws_ag_procedure_parent_flag_detail' );

    }
}


// ════════════════════════════════════════════════════════════════════════════
// Publish Gate
//
// Intercepts wp_insert_post_data before any write to the procedures post
// table. Catches publish attempts from quick edit, bulk action, REST API,
// and programmatic wp_publish_post() — contexts where acf/save_post never
// fires and the demotion above cannot run.
//
// Exception: admins submitting the ACF override field in a single step
// (publish + override checked) bypass the gate so the publish goes through.
// The detection hook (priority 20) then clears the flag and resets override.
// ════════════════════════════════════════════════════════════════════════════

add_filter( 'wp_insert_post_data', 'ws_ag_procedure_gate_publish', 10, 2 );

/**
 * Prevents flagged ag-procedure posts from being published.
 *
 * @param  array  $data     The post data array about to be written.
 * @param  array  $postarr  The raw submitted post array.
 * @return array
 */
function ws_ag_procedure_gate_publish( $data, $postarr ) {

    if ( ( $data['post_type'] ?? '' ) !== 'ag-procedure' ) {
        return $data;
    }

    if ( ( $data['post_status'] ?? '' ) !== 'publish' ) {
        return $data;
    }

    $post_id = (int) ( $postarr['ID'] ?? 0 );
    if ( ! $post_id ) {
        return $data;
    }

    // Direct meta read — wp_insert_post_data fires before the post is saved; reading the flag
    // state here to gate publish. Query layer is not appropriate in this filter context.
    $parent_flag = get_post_meta( $post_id, 'ws_ag_procedure_parent_flagged', true );
   if ( ! $parent_flag ) {
        return $data; // Not flagged — allow publish.
    }

    // Flagged. Check for admin submitting override via the ACF edit screen.
    // $_POST['acf'] is only populated on full ACF form submits, not on
    // quick edit / bulk action / REST / programmatic saves — so non-admin
    // contexts naturally fail this check and are always gated.
    $is_admin = current_user_can( 'manage_options' );
    if (( $is_admin ) &&  ! empty( $_POST['acf']['field_ag_procedure_parent_override'] )) {  // phpcs:ignore WordPress.Security.NonceVerification.Missing
    
        return $data; // Admin override acknowledged — allow publish this once.
    }

    // Force draft. The editor will see the admin notice explaining why.
    $data['post_status'] = 'draft';

    return $data;
}


// ════════════════════════════════════════════════════════════════════════════
// Admin Notice
//
// Displays on the procedure edit screen (post.php) when flag meta is set.
// Scoped to ag-procedure only — not a global admin notice.
//
// Hard mismatch: error-level notice listing each flagged statute or common law
// with title. Broad-scope advisory: warning-level notice (no demotion,
// informational). Both may appear simultaneously.
// ════════════════════════════════════════════════════════════════════════════

add_action( 'admin_notices', 'ws_ag_procedure_conflict_admin_notice' );

/**
 * Renders authority link validation notices on the procedure edit screen.
 */
function ws_ag_procedure_conflict_admin_notice() {

    $screen = get_current_screen();
    if ( ! $screen || 'post' !== $screen->base || 'ag-procedure' !== $screen->post_type ) {
        return;
    }

    global $post;
    if ( ! $post ) {
        return;
    }

    $post_id    = $post->ID;
    $is_admin   = current_user_can( 'manage_options' );
    // Direct meta reads — admin notice display only; query layer is for front-end shortcode rendering.
    $flagged    = (bool) get_post_meta( $post_id, 'ws_ag_procedure_parent_flagged',    true );
    $broad      = (bool) get_post_meta( $post_id, 'ws_ag_procedure_parent_broad_scope', true );
    $detail_raw = get_post_meta( $post_id, 'ws_ag_procedure_parent_flag_detail',       true );
    $mismatches = $detail_raw ? json_decode( $detail_raw, true ) : [];
    if ( ! is_array( $mismatches ) ) $mismatches = [];

    // ── Hard mismatch notice ───────────────────────────────────────────────

    if ( $flagged && ! empty( $mismatches ) ) {
        echo '<div class="notice notice-error">';
        echo '<p><strong>Authority Link Issue — This Procedure Is Saved as a Draft</strong></p>';
        echo '<p>The following linked authorities do not share a protected disclosure with this procedure. ';
        echo 'Publishing is blocked until the issues are resolved or an administrator overrides.</p>';
        echo '<ul>';
        foreach ( $mismatches as $m ) {
            $parent_type  = ! empty( $m['parent_type'] ) ? $m['parent_type'] : 'statute';
            $parent_id    = isset( $m['parent_id'] ) ? absint( $m['parent_id'] ) : absint( $m['statute_id'] ?? 0 );
            $parent_title = ! empty( $m['parent_title'] ) ? $m['parent_title'] : ( $m['statute_title'] ?? '' );
            $record_label = ( 'common_law' === $parent_type ) ? 'Common Law' : 'Statute';
            $safe_title   = $parent_title ? esc_html( $parent_title ) : $record_label . ' ID ' . $parent_id;
            echo '<li><strong>' . esc_html( $record_label ) . ':</strong> <strong>' . $safe_title . '</strong> — protected disclosure does not intersect with this procedure\'s categories.</li>';
        }
        echo '</ul>';

        if ( $is_admin ) {
            echo '<p>To resolve: fix the linked record\'s or procedure\'s protected disclosure taxonomy, then re-save. '
               . 'Alternatively, use the <strong>Admin Review</strong> tab to override if this link is intentionally unconventional.</p>';
        } else {
            echo '<p>To resolve: update the linked record\'s or procedure\'s protected disclosure category, then re-save. '
               . 'Contact an administrator if the link is correct but the taxonomy data needs adjustment.</p>';
        }

        echo '</div>';
    }

    // ── Broad-scope advisory notice ────────────────────────────────────────

    if ( $broad ) {
        echo '<div class="notice notice-warning">';
        echo '<p><strong>Authority Links — Scope Advisory</strong></p>';
        echo '<p>This procedure has no Protected Disclosures set. Authority pickers may show broad/unfiltered results ';
        echo 'when links were selected — automatic verification is not possible. ';
        echo 'Please confirm each linked authority is specifically applicable to this procedure.</p>';
        echo '</div>';
    }
}
