<?php
/**
 * File: admin-navigation.php
 *
 * WhistleblowerShield Core Plugin
 *
 * PURPOSE
 * -------
 * Adds an administrative navigation panel inside the Jurisdiction
 * editor to quickly access related dataset records.
 *
 * Without this panel, editors must manually navigate WordPress
 * menus to locate related records such as:
 *
 *      • Summary
 *      • Statutes
 *      • Common Law
 *
 * This file improves workflow by providing direct edit links to
 * related datasets.
 *
 *
 * ARCHITECTURE
 * ------------
 *
 * jurisdiction (core record)
 *      ├── jx-summary                  (one-to-one, scoped by ws_jurisdiction taxonomy)
 *      ├── jx-statute or jx-common-law (one-to-many, scoped by ws_jurisdiction taxonomy)
 *      └── jx-citation                 (many-to-one, scoped by ws_jurisdiction taxonomy + ws_jx_citation_has_attach_flag)
 *
 *
 * SHARED HELPER
 * -------------
 * ws_get_attached_citation_count( $post_id )
 *
 * Returns the number of published jx-citation records assigned the same
 * ws_jurisdiction term as the given jurisdiction post with ws_jx_citation_has_attach_flag = 1.
 * Defined here and shared by admin-columns.php and
 * jurisdiction-dashboard.php (both load after this file).
 *
 *
 * WORKFLOW BENEFIT
 * ----------------
 *
 * Editors can jump directly between related records while
 * developing jurisdiction content.
 *
 *
 * VERSION
 * -------
 * 2.1.0  Initial admin navigation implementation
 * 2.1.3  Smart creation support (Create Now links)
 * 2.3.1  Fixed CPT slug typos (jx_summary → jx-summary for all four).
 *        Added ws_get_attached_citation_count() shared helper.
 *        Added Citations row: count badge + Add Citation + View All.
 * 3.0.0  Architecture refactor (Phase 3.2):
 *        - Resources row removed (CPT deleted).
 *        - Create Now and Add Citation URLs migrated from ws_jx_code query
 *          arg to ws_jx_term (taxonomy term slug).
 *        - ws_get_attached_citation_count() migrated from ws_jx_code meta
 *          query to ws_jurisdiction taxonomy query with ws_jx_citation_has_attach_flag meta.
 * 3.1.0  Added Legal Updates, Agencies, and Assist-Orgs count rows.
 *        All three use taxonomy-scoped count queries with View All links.
 * 3.9.0  Added ws_add_agency_navigation_box() and ws_render_agency_navigation_box()
 *        for the ws-agency edit screen. Lists attached procedures with edit
 *        links and an Add Procedure button that pre-fills the parent agency.
 *
 * @package WhistleblowerShield
 * @since   2.1.0
 * @version 3.10.0
 */
if (!defined('ABSPATH')) {
    exit;
}


/*
---------------------------------------------------------
Add Meta Box
---------------------------------------------------------
*/

add_action('add_meta_boxes', 'ws_add_jx_navigation_box');

function ws_add_jx_navigation_box()
{

    add_meta_box(
        'ws_jx_navigation',
        'Jurisdiction Data Navigation',
        'ws_render_jx_navigation_box',
        'jurisdiction',
        'side',
        'high'
    );

}


/*
---------------------------------------------------------
Render Navigation Box
---------------------------------------------------------
*/

function ws_render_jx_navigation_box($post) {

    // Resolve taxonomy term slug for this jurisdiction (used to scope addendum queries).
    $jx_slugs  = wp_get_post_terms( $post->ID, WS_JURISDICTION_TAXONOMY, [ 'fields' => 'slugs' ] );
    $term_slug = ( ! is_wp_error( $jx_slugs ) && ! empty( $jx_slugs ) ) ? $jx_slugs[0] : '';
    $term      = $term_slug ? ws_jx_term_by_code( $term_slug ) : null;
    $term_id   = ( $term && ! is_wp_error( $term ) ) ? $term->term_id : 0;

    // Look up existing addendum posts via taxonomy (replaces get_field on relationship fields).
    $summary_post    = null;
    $statutes_post   = null;
    $common_law_post = null;

    if ( $term_id ) {
        $summary_id = ws_find_related_jx_record_id( 'jx-summary', $term_id );
        if ( $summary_id ) {
            $summary_post = get_post( $summary_id );
        }

        $statute_id = ws_find_related_jx_record_id( 'jx-statute', $term_id );
        if ( $statute_id ) {
            $statutes_post = get_post( $statute_id );
        }

        $common_law_id = ws_find_related_jx_record_id( 'jx-common-law', $term_id );
        if ( $common_law_id ) {
            $common_law_post = get_post( $common_law_id );
        }
    }

    echo '<div class="ws-admin-nav-wrapper" style="line-height:1.6;">';

    ws_render_admin_link('Summary',  $summary_post,  'jx-summary', $post->ID);
    ws_render_admin_link('Statutes', $statutes_post, 'jx-statute', $post->ID);
    ws_render_admin_link('Common Law', $common_law_post, 'jx-common-law', $post->ID);

    ws_render_citation_row( $post->ID );
    ws_render_cpt_count_row( $post->ID, $term_slug, 'ws-legal-update', 'Legal Updates' );
    ws_render_cpt_count_row( $post->ID, $term_slug, 'ws-agency',       'Agencies' );
    ws_render_cpt_count_row( $post->ID, $term_slug, 'ws-assist-org',   'Assist Orgs' );

    echo '</div>';
}

/**
 * Returns one related CPT record for a jurisdiction term, preferring publish.
 *
 * Uses deterministic ordering (`modified DESC`) within each status bucket.
 *
 * @param string $post_type CPT slug.
 * @param int    $term_id   ws_jurisdiction term ID.
 * @return int              Related post ID, or 0 when none found.
 */
function ws_find_related_jx_record_id( $post_type, $term_id ) {
    $post_type = (string) $post_type;
    $term_id   = (int) $term_id;
    if ( $post_type === '' || ! $term_id ) {
        return 0;
    }

    $base_args = [
        'post_type'      => $post_type,
        'posts_per_page' => 1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'orderby'        => 'modified',
        'order'          => 'DESC',
        'tax_query'      => [ [ 'taxonomy' => WS_JURISDICTION_TAXONOMY, 'field' => 'term_id', 'terms' => $term_id ] ],
    ];

    $publish_ids = get_posts( $base_args + [ 'post_status' => 'publish' ] );
    if ( ! empty( $publish_ids ) ) {
        return (int) $publish_ids[0];
    }

    $draft_ids = get_posts( $base_args + [ 'post_status' => [ 'draft', 'pending' ] ] );
    if ( ! empty( $draft_ids ) ) {
        return (int) $draft_ids[0];
    }

    return 0;
}


/*
---------------------------------------------------------
Helper: Render Link
---------------------------------------------------------
*/

function ws_render_admin_link($label, $related, $post_type, $parent_id) {
    echo '<div style="margin-bottom: 12px; padding: 8px; border: 1px solid #ccd0d4; border-radius: 4px; background: #fff;">';
    echo '<strong style="display: block; margin-bottom: 5px;">' . esc_html($label) . '</strong>';

    if ($related) {
        $status = get_post_status($related->ID);
        $color  = ($status === 'publish') ? '#46b450' : '#ffa500';
        echo '<span style="font-size: 11px; color: ' . $color . ';">● ' . ucfirst($status) . '</span><br>';
        echo '<a class="button button-small" href="' . get_edit_post_link($related->ID) . '">Edit Record</a>';
    } else {
        // Build the Smart Link — passes ws_jx_term (taxonomy term slug) so the
        // new-post screen auto-assigns the ws_jurisdiction taxonomy term via
        // the wp_insert_post hook in admin-hooks.php.
        $parent_name = get_the_title( $parent_id );
        $jx_slugs    = wp_get_post_terms( $parent_id, WS_JURISDICTION_TAXONOMY, [ 'fields' => 'slugs' ] );
        $term_slug   = ( ! is_wp_error( $jx_slugs ) && ! empty( $jx_slugs ) ) ? $jx_slugs[0] : '';
        $create_url  = add_query_arg( [
            'post_type'  => $post_type,
            'ws_jx_term' => $term_slug,
            'post_title' => "{$parent_name} {$label}",
        ], admin_url( 'post-new.php' ) );

        echo '<span style="font-size: 11px; color: #dc3232;">● Not Created</span><br>';
        echo '<a class="button button-small button-primary" href="' . esc_url($create_url) . '">Create Now</a>';
    }
    echo '</div>';
}


/*
---------------------------------------------------------
Shared Helper: Attached Citation Count
---------------------------------------------------------
Returns the number of published jx-citation records that
are scoped to this jurisdiction (ws_jurisdiction taxonomy)
and have ws_jx_citation_has_attach_flag set to true.

Shared by:
    admin-columns.php          — jurisdiction list table column
    jurisdiction-dashboard.php — health matrix row
---------------------------------------------------------
*/

function ws_get_attached_citation_count( $post_id ) {

    $terms = wp_get_post_terms( $post_id, WS_JURISDICTION_TAXONOMY );

    if ( empty( $terms ) || is_wp_error( $terms ) ) {
        return 0;
    }

    $term_id = $terms[0]->term_id;

    $query = new WP_Query( [
        'post_type'      => 'jx-citation',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'meta_query'     => [
            [
                'key'     => 'ws_jx_citation_has_attach_flag',
                'value'   => '1',
                'compare' => '=',
            ],
        ],
        'tax_query' => [ [
            'taxonomy' => WS_JURISDICTION_TAXONOMY,
            'field'    => 'term_id',
            'terms'    => $term_id,
        ] ],
    ] );

    return (int) $query->found_posts;
}


/*
---------------------------------------------------------
Render: CPT Count Row
---------------------------------------------------------
Generic count row for CPTs that are scoped by ws_jurisdiction
taxonomy but don't use the attached-flag pattern (legal updates,
agencies, assist-orgs). Shows a count badge and a View All link
filtered by taxonomy term.

    0 records → red badge
    1+ records → green badge
---------------------------------------------------------
*/

function ws_render_cpt_count_row( $post_id, $term_slug, $post_type, $label ) {

    $terms   = wp_get_post_terms( $post_id, WS_JURISDICTION_TAXONOMY );
    $term_id = ( ! is_wp_error( $terms ) && ! empty( $terms ) ) ? (int) $terms[0]->term_id : 0;

    $count = 0;
    if ( $term_id ) {
        $q = new WP_Query( [
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'no_found_rows'  => false,
            'tax_query'      => [ [
                'taxonomy' => WS_JURISDICTION_TAXONOMY,
                'field'    => 'term_id',
                'terms'    => $term_id,
            ] ],
        ] );
        $count = (int) $q->found_posts;
    }

    $badge_color = $count > 0 ? '#46b450' : '#dc3232';

    $all_url = add_query_arg( [
        'post_type'            => $post_type,
        WS_JURISDICTION_TAXONOMY => $term_slug,
    ], admin_url( 'edit.php' ) );

    echo '<div style="margin-bottom: 12px; padding: 8px; border: 1px solid #ccd0d4; border-radius: 4px; background: #fff;">';
    echo '<strong style="display: block; margin-bottom: 5px;">' . esc_html( $label ) . '</strong>';
    echo '<span style="font-size: 11px; color: ' . esc_attr( $badge_color ) . ';">● ' . (int) $count . ' published</span><br>';
    echo '<div style="margin-top: 5px;">';
    echo '<a class="button button-small" href="' . esc_url( $all_url ) . '">View All</a>';
    echo '</div>';
    echo '</div>';
}


/*
---------------------------------------------------------
Render: Citations Row
---------------------------------------------------------
Always rendered — shows attached count with color-coded
threshold badge, plus Add Citation and View All buttons.

    0 citations   → red badge
    1–2 citations → orange badge
    3+ citations  → green badge

"Add Citation" links to new jx-citation with ws_jx_term in the URL.
"View All" filters the jx-citation list by taxonomy term.
---------------------------------------------------------
*/

function ws_render_citation_row( $post_id ) {

    $jx_slugs  = wp_get_post_terms( $post_id, WS_JURISDICTION_TAXONOMY, [ 'fields' => 'slugs' ] );
    $term_slug = ( ! is_wp_error( $jx_slugs ) && ! empty( $jx_slugs ) ) ? $jx_slugs[0] : '';
    $count     = ws_get_attached_citation_count( $post_id );

    if ( $count === 0 ) {
        $badge_color = '#dc3232'; // red
    } elseif ( $count <= 2 ) {
        $badge_color = '#ffa500'; // orange
    } else {
        $badge_color = '#46b450'; // green
    }

    $add_url = add_query_arg( [
        'post_type'  => 'jx-citation',
        'ws_jx_term' => $term_slug,
    ], admin_url( 'post-new.php' ) );

    $all_url = add_query_arg( [
        'post_type'      => 'jx-citation',
        WS_JURISDICTION_TAXONOMY => $term_slug,
    ], admin_url( 'edit.php' ) );

    echo '<div style="margin-bottom: 12px; padding: 8px; border: 1px solid #ccd0d4; border-radius: 4px; background: #fff;">';
    echo '<strong style="display: block; margin-bottom: 5px;">Citations</strong>';
    echo '<span style="font-size: 11px; color: ' . esc_attr( $badge_color ) . ';">● ' . (int) $count . ' attached</span><br>';
    echo '<div style="margin-top: 5px; display: flex; gap: 5px; flex-wrap: wrap;">';
    echo '<a class="button button-small button-primary" href="' . esc_url( $add_url ) . '">Add Citation</a>';
    echo '<a class="button button-small" href="' . esc_url( $all_url ) . '">View All</a>';
    echo '</div>';
    echo '</div>';
}


// ════════════════════════════════════════════════════════════════════════════
// Agency Navigation Box
//
// Adds a Procedures panel to the ws-agency edit screen listing all
// procedures attached to this agency. Provides direct edit links and
// an Add Procedure button that pre-fills the parent agency via ?agency_id=.
//
// The agency_id URL parameter is read by ws_ag_procedure_prefill_agency_id() in
// acf-ag-procedures.php, which pre-selects the parent agency on auto-draft
// posts — matching the pattern used for interpretations and statutes.
// ════════════════════════════════════════════════════════════════════════════

add_action( 'add_meta_boxes', 'ws_add_agency_navigation_box' );

function ws_add_agency_navigation_box() {
    add_meta_box(
        'ws_agency_procedures',
        'Procedures',
        'ws_render_agency_navigation_box',
        'ws-agency',
        'side',
        'default'
    );
}

function ws_render_agency_navigation_box( $post ) {

    // Query procedures attached to this agency via ws_ag_procedure_agency_id meta.
    $procedures = get_posts( [
        'post_type'      => 'ws-ag-procedure',
        'post_status'    => [ 'publish', 'draft', 'pending' ],
        'posts_per_page' => 50,
        'no_found_rows'  => true,
        'meta_query'     => [ [
            'key'     => 'ws_ag_procedure_agency_id',
            'value'   => $post->ID,
            'compare' => '=',
        ] ],
    ] );

    $type_labels = [
        'disclosure'  => 'Disclosure',
        'retaliation' => 'Retaliation',
        'both'        => 'Both',
    ];

    $add_url = add_query_arg( [
        'post_type' => 'ws-ag-procedure',
        'agency_id' => $post->ID,
    ], admin_url( 'post-new.php' ) );

    $all_url = add_query_arg( [
        'post_type' => 'ws-ag-procedure',
    ], admin_url( 'edit.php' ) );

    echo '<div style="line-height:1.6;">';

    if ( empty( $procedures ) ) {
        echo '<p style="color:#999;font-size:12px;margin:0 0 8px;">No procedures yet.</p>';
    } else {
        echo '<ul style="margin:0 0 10px;padding-left:0;list-style:none;">';
        foreach ( $procedures as $proc ) {
            $type_terms = wp_get_object_terms( $proc->ID, 'ws_procedure_type', [ 'fields' => 'slugs' ] );
            $type       = ( ! is_wp_error( $type_terms ) && ! empty( $type_terms ) ) ? (string) $type_terms[0] : '';
            $type_lbl   = $type_labels[ $type ] ?? '';
            $status   = get_post_status( $proc->ID );
            $color    = ( $status === 'publish' ) ? '#46b450' : '#ffa500';
            echo '<li style="margin-bottom:6px;padding:6px;background:#f9f9f9;border:1px solid #e5e5e5;border-radius:3px;">';
            echo '<a href="' . esc_url( get_edit_post_link( $proc->ID ) ) . '" style="font-weight:600;">' . esc_html( get_the_title( $proc->ID ) ) . '</a><br>';
            echo '<span style="font-size:11px;color:#666;">' . esc_html( $type_lbl ) . '</span> ';
            echo '<span style="font-size:11px;color:' . esc_attr( $color ) . ';">● ' . esc_html( ucfirst( $status ) ) . '</span>';
            echo '</li>';
        }
        echo '</ul>';
    }

    echo '<div style="display:flex;gap:5px;flex-wrap:wrap;">';
    echo '<a class="button button-small button-primary" href="' . esc_url( $add_url ) . '">Add Procedure</a>';
    if ( ! empty( $procedures ) ) {
        echo '<a class="button button-small" href="' . esc_url( $all_url ) . '">View All</a>';
    }
	    echo '</div>';
	    echo '</div>';
	}
